#!/bin/sh

cd $HOME

#
# make (if not yet existing) pulseaudio config directory
# (use sequence of echo command to fuse strings into long lines)
#
mkdir -p $HOME/.config/pulse

export OUT=$HOME/.config/pulse/default.pa

echo " .include /etc/pulse/default.pa"                        >> $OUT

echo "load-module module-null-sink sink_name=SDR-RX" \
   "sink_properties="device.description=SDR-RX" rate=48000"   >> $OUT
echo "load-module module-null-sink sink_name=SDR-TX" \
   "sink_properties="device.description=SDR-TX" rate=48000"   >> $OUT

echo "set-default-sink    SDR-TX"                             >> $OUT
echo "set-default-source  SDR-RX.monitor"                     >> $OUT

#EOF

